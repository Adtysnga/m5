import 'dart:convert';
import "Home.dart";
import 'package:http/http.dart' as http;
import 'dart:io';
import 'MoviesModel.dart';

class HttpHelper {
  final String _urlKey = "?api_key=5c1363f9cd878363a2aa050bb4b6a121";
  final String _urlBase = "https://api.themoviedb.org";

  Future<List?> getMovie() async {
    var url = Uri.parse(_urlBase + "/3/movie/now_playing" + _urlKey);
    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      final jsonResponse = json.decode(result.body);
      final moviesMap = jsonResponse['results'];
      List movies = moviesMap.map((i) => Movie.fromJson(i)).toList();
      return movies;
    } else {
      return null;
    }
    ;
  }
}
